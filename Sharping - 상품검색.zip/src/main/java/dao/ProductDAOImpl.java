package dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;

import vo.ProductListVO;

public class ProductDAOImpl implements ProductDAO {
	
	private SqlSessionTemplate sqlSessionTemplate;
	
	@Override
	public List<ProductListVO> ProductList() {
		return sqlSessionTemplate.selectList("productDAO.selectProduct");
	}

	@Override
	public ProductListVO selectProductList(String productName) {
		return sqlSessionTemplate.selectOne("productDAO.selectProduct", productName);
	}
}
