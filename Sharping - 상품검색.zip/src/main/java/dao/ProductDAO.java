package dao;

import java.util.List;

import vo.ProductListVO;

public interface ProductDAO {

	//상폼리스트
	public List<ProductListVO> ProductList();

	//상품검색
	public ProductListVO selectProductList(String productName);
	
}
