package vo;

public class ProductListVO {
	private String productImage;
	private String productName;
	private int productPrice;
	private int deliveryPrice;
	private String productThumb;
	private String sellerId;
	
	public ProductListVO() {
		
	}
	
	public ProductListVO(String productImage, String productName, int productPrice, int deliveryPrice,
			String productThumb, String sellerId) {
		super();
		this.productImage = productImage;
		this.productName = productName;
		this.productPrice = productPrice;
		this.deliveryPrice = deliveryPrice;
		this.productThumb = productThumb;
		this.sellerId = sellerId;
	}
	public String getProductImage() {
		return productImage;
	}
	public void setProductImage(String productImage) {
		this.productImage = productImage;
	}
	public String getProductName() {
		return productName;
	}
	public void setProductName(String productName) {
		this.productName = productName;
	}
	public int getProductPrice() {
		return productPrice;
	}
	public void setProductPrice(int productPrice) {
		this.productPrice = productPrice;
	}
	public int getDeliveryPrice() {
		return deliveryPrice;
	}
	public void setDeliveryPrice(int deliveryPrice) {
		this.deliveryPrice = deliveryPrice;
	}
	public String getProductThumb() {
		return productThumb;
	}
	public void setProductThumb(String productThumb) {
		this.productThumb = productThumb;
	}
	public String getSellerId() {
		return sellerId;
	}
	public void setSellerId(String sellerId) {
		this.sellerId = sellerId;
	}
	
	
	
}
