package service;

import java.util.List;

import org.springframework.stereotype.Service;

import dao.ProductDAO;
import vo.ProductListVO;

@Service
public class ProductServiceImpl implements ProductService {
	
	@Override
	public List<ProductListVO> ProductList() {
		return ProductDAO.ProductList();
	}
	
	@Override
	public ProductListVO searchProductList(String productName) {
		return ProductDAO.selectProductList(productName);
	}
	
}
