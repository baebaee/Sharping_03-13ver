package service;

import java.util.List;

import vo.ProductListVO;


public interface ProductService {

	//상품리스트
	public List<ProductListVO> ProductList();

	//상품검색
	public ProductListVO searchProductList(String productName);


}