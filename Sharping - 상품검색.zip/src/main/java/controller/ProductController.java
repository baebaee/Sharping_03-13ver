package controller;

import java.util.List;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import service.ProductService;
import vo.ProductListVO;

@Controller
public class ProductController {

	private ProductService productService;
	
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}
	
	//상품 리스트
	@RequestMapping(value = "/searchProduct")
	public String ProductList(String productName, Model model) {
		List<ProductListVO> list = productService.ProductList();
		model.addAttribute("list", list);
		return "product/SearchResult";
	}
	
//	@RequestMapping(value = "/searchProduct")
//	public String searchProductList(String productName, Model model) {
//		List<ProductListVO> list = productService.searchProduct(productName);
//		model.addAttribute("list", list);
//		return "product/SearchResult";
//	}	
	
	//상품 검색
	@RequestMapping(value="/searchProduct")
	public String searchProductList(String productName, Model model) {
		ProductListVO productListVO = productService.searchProductList(productName);
		model.addAttribute("productListVO", productListVO);
		return "product/SearchResult";
	}
	
	// 상품 검색 페이지
	@RequestMapping(value= "/SearchProduct")
	public String SearchProduct() {
		return "MainPage";
	}
}
