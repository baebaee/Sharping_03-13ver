package exception;

public class AlreadyExistingIdException extends RuntimeException{

}
