package exception;

public class PasswordNotMatchingException extends RuntimeException{

}
