package dao;

import vo.AdminVO;

public interface AdminDAO {

	public abstract AdminVO selectAdminById(String adminId);
	
	public abstract int insertAdmin(AdminVO adminVO);
	
	public abstract int selectAdminId(String adminId);
	
}
