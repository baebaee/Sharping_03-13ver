package dao;

import org.mybatis.spring.SqlSessionTemplate;

import vo.AdminVO;

public class AdminDAOImpl implements AdminDAO {
	
	private SqlSessionTemplate sqlSessionTemplate;

	
	public AdminDAOImpl(SqlSessionTemplate sqlSessionTemplate) {
		this.sqlSessionTemplate = sqlSessionTemplate;
	}
	
	@Override
	public AdminVO selectAdminById(String adminId) {
		return sqlSessionTemplate.selectOne("adminDAO.selectAdminById", adminId);
	}
	
	@Override
	public int insertAdmin(AdminVO adminVO) {
		return sqlSessionTemplate.insert("adminDAO.insertAdmin", adminVO);
	}
	
	@Override
	public int selectAdminId(String adminId) {
		int result = sqlSessionTemplate.selectOne("adminDAO.selectAdminId", adminId);
		return result;
	}

}
