package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import service.ProductService;
import vo.SearchVO;

@Controller
public class ProductController {

	private ProductService productService;
	
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}
	
	// 상품 검색 페이지
	@RequestMapping(value= "/searchProduct")
	public String SearchProduct() {
		return "MainPage";
	}
	
	// 상품 리스트 페이지
	@RequestMapping(value ="/productList", method = RequestMethod.GET)
	public String getProductList(Model model,
								@RequestParam(required=false, defaultValue = "productName") String searchType,
								@RequestParam(required=false) String keyword, @RequestParam(required=false) String keyword2
								) throws Exception{
		SearchVO search = new SearchVO();
		search.setSearchType(searchType);
		search.setKeyword(keyword);
		search.setKeyword2(keyword2);
		
		model.addAttribute("productList", productService.getProductList(search));
		model.addAttribute("keyword", keyword);
		return "product/SearchResult";
	}


}
