package controller;

import javax.validation.Valid;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import exception.AlreadyExistingIdException;
import service.AdminService;
import service.MemberService;
import vo.AdminVO;
import vo.MemberVO;

@Controller
public class AdminController {

	private AdminService adminService;
	private MemberService memberService;

	public MemberService getMemberService() {
		return memberService;
	}

	public void setMemberService(MemberService memberService) {
		this.memberService = memberService;
	}

	public AdminService getAdminService() {
		return adminService;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}

	// 관리자 메인
	@RequestMapping("/admin")
	public String admin() {
		return "admin/AdminPage";
	}
	
	// 새 관리자등록
	@RequestMapping("/admin/registerAdmin")
	public String registerAdmin() {
		return "admin/RegisterAdmin";
	}

	// 아이디 중복확인
	@RequestMapping(value = "/adminIdCheck")
	@ResponseBody
	public int adminIdCheck(@Valid String adminId) {
		int result = adminService.adminIdCheck(adminId);
		System.out.println("1나오냐" + result);
		return result;
	}

	// 새 관리자 등록 완료
	@RequestMapping(value = "/admin/registerCompleteAdmin")
	public String registCompleteMember(@Valid AdminVO adminVO) {

		String pw = adminVO.getAdminPassword();
		String hashPw = BCrypt.hashpw(pw, BCrypt.gensalt());
		adminVO.setAdminPassword(hashPw);
		int result = adminService.adminIdCheck(adminVO.getAdminId());
		if (result == 1) {
			throw new AlreadyExistingIdException();
		}
		adminService.registAdmin(adminVO);
		return "redirect:/admin";
	}

	// 카테고리관리
	@RequestMapping("/admin/categoryManage")
	public String categoryManage() {
		return "admin/CategoryManage";
	}

	// 회원관리
	@RequestMapping("/admin/memberList")
	public String memberManage() {
		return "admin/MemberManage";
	}

	// 일반회원목록리스트

	@RequestMapping(value = "/admin/memberList", method = RequestMethod.GET)
	public String getMemberList(Model model, @RequestParam(required = false) String keywordM) throws Exception {
		AdminVO adminVO = new AdminVO();
		adminVO.setKeywordM(keywordM);

		model.addAttribute("memberList", adminService.getMemberList(adminVO));
		model.addAttribute("sellerList", adminService.getSellerList(adminVO));
		model.addAttribute("keywordM", keywordM);

		return "admin/MemberManage";
	}

	// 일반회원목록리스트
	@RequestMapping(value = "/admin/memberManage", method = RequestMethod.GET)
	public String memberManage(Model model, @RequestParam(required = false) String keywordM) throws Exception {
		AdminVO adminVO = new AdminVO();
		adminVO.setKeywordM(keywordM);

		model.addAttribute("memberList", adminService.getMemberList(adminVO));
		model.addAttribute("sellerList", adminService.getSellerList(adminVO));
		model.addAttribute("keywordM", keywordM);

		return "admin/MemberManage";
	}

	// 판매회원목록리스트
	@RequestMapping(value = "/admin/sellerList", method = RequestMethod.GET)
	public String getSellerList(Model model, @RequestParam(required = false) String keywordM) throws Exception {
		AdminVO adminVO = new AdminVO();
		adminVO.setKeywordM(keywordM);

		model.addAttribute("memberList", adminService.getMemberList(adminVO));
		model.addAttribute("sellerList", adminService.getSellerList(adminVO));
		model.addAttribute("keywordM", keywordM);

		return "admin/MemberManage";
	}
	
	// 회원세부정보 열람
	@RequestMapping("/admin/infoDetail")
	public ModelAndView infoDetail(String id) {
		MemberVO memberVO = memberService.searchMemberById(id);
		
		System.out.println(id);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("admin/InfoDetail");
		mv.addObject("member", memberVO);
		return mv;
	}

	// 공지사항관리
	@RequestMapping("/admin/noticeManage")
	public String noticeManage() {
		return "admin/NoticeManage";
	}
}
