package dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;

import controller.Search;
import vo.ProductListVO;

public class ProductDAOImpl implements ProductDAO {
	
	private SqlSessionTemplate sqlSessionTemplate;

	public ProductDAOImpl() {
		super();
	}

	public ProductDAOImpl(SqlSessionTemplate sqlSessionTemplate) {
		super();
		this.sqlSessionTemplate = sqlSessionTemplate;
	}
	
	public SqlSessionTemplate getSqlSessionTemplate() {
		return sqlSessionTemplate;
	}

	public void setSqlSessionTemplate(SqlSessionTemplate sqlSessionTemplate) {
		this.sqlSessionTemplate = sqlSessionTemplate;
	}

	
	
	@Override
	public List<ProductListVO> getProductList(Search search) {
		return sqlSessionTemplate.selectList("productDAO.getProductList", search);
	}

}
