package dao;

import java.util.List;

import controller.Search;
import vo.ProductListVO;

public interface ProductDAO {

	//상폼리스트
	public List<ProductListVO> getProductList(Search search) throws Exception;

	
}
