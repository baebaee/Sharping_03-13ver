package service;

import java.util.List;

import org.springframework.stereotype.Service;

import controller.Search;
import dao.ProductDAO;
import vo.ProductListVO;

@Service
public class ProductServiceImpl implements ProductService {
	
	private ProductDAO productDAO;
	
	public ProductServiceImpl() {
		super();
	}

	public ProductDAO getProductDAO() {
		return productDAO;
	}

	public void setProductDAO(ProductDAO productDAO) {
		this.productDAO = productDAO;
	}

	public ProductServiceImpl(ProductDAO productDAO) {
		super();
		this.productDAO = productDAO;
	}

	@Override
	public List<ProductListVO> getProductList(Search search) throws Exception {
		return productDAO.getProductList(search);
	}
	
}
