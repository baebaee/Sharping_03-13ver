package service;

import java.util.List;

import controller.Search;
import vo.ProductListVO;


public interface ProductService {

	public List<ProductListVO> getProductList(Search search) throws Exception;
	
}