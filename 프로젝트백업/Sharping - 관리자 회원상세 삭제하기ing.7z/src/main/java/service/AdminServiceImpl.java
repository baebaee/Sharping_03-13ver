package service;

import java.util.List;

import org.springframework.security.crypto.bcrypt.BCrypt;

import dao.AdminDAO;
import dao.MemberDAO;
import exception.IdPasswordNotMatchingException;
import vo.AdminVO;
import vo.MemberVO;
import vo.SellerVO;

public class AdminServiceImpl implements AdminService {

	private AdminDAO adminDAO;
	private MemberDAO memberDAO;
	private AdminVO adminVO;
	private MemberVO memberVO;
	

	public AdminServiceImpl() {
		super();
	}

	public AdminServiceImpl(AdminDAO adminDAO) {
		super();
		this.adminDAO = adminDAO;
	}

	public AdminDAO getAdminDAO() {
		return adminDAO;
	}

	public void setAdminDAO(AdminDAO adminDAO) {
		this.adminDAO = adminDAO;
	}
	
	public MemberDAO getMemberDAO() {
		return memberDAO;
	}

	public void setMemberDAO(MemberDAO memberDAO) {
		this.memberDAO = memberDAO;
	}

	public AdminVO searchAdminById(String adminId) {
		return adminDAO.selectAdminById(adminId);
	}
	
	@Override
	public AdminVO login(String adminId, String adminPassword) {
		AdminVO adminVO = adminDAO.selectAdminById(adminId);

		if (adminVO == null) {
			return null;
		}
		if (!BCrypt.checkpw(adminPassword, adminVO.getAdminPassword())) {
			throw new IdPasswordNotMatchingException();
		} else {
			return new AdminVO(adminVO.getAdminId(), adminVO.getAdminPassword());
		}
	}
	
	@Override
	public int registAdmin(AdminVO adminVO) {
		return adminDAO.insertAdmin(adminVO);
	}
	
	@Override
	public int adminIdCheck(String adminId) {
		int result = adminDAO.selectAdminId(adminId);
		return result;
	}
	
	@Override
	public List<MemberVO> getMemberList(AdminVO adminVO) throws Exception {
		return adminDAO.getMemberList(adminVO);
	}
	
	@Override
	public List<SellerVO> getSellerList(AdminVO adminVO) throws Exception {
		return adminDAO.getSellerList(adminVO);
	}
	
	@Override
	public int deleteMemberById(MemberVO memberVO) {
		return adminDAO.deleteMemberById(memberVO);
	}

}
