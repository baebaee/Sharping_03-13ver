package service;

import java.util.List;

import vo.AdminVO;
import vo.MemberVO;
import vo.SellerVO;

public interface AdminService {
	
	public abstract AdminVO searchAdminById(String adminId);
	
	public abstract AdminVO login(String adminId, String adminPassword);
	
	public abstract int registAdmin(AdminVO adminVO);
	
	public abstract int adminIdCheck(String adminId);

	public abstract List<MemberVO> getMemberList(AdminVO adminVO) throws Exception;

	public abstract List<SellerVO> getSellerList(AdminVO adminVO) throws Exception;
	
	public abstract int deleteMemberById(MemberVO memberVO);

}
