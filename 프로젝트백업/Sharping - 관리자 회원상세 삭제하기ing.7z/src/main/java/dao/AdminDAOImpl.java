package dao;

import java.util.List;

import org.mybatis.spring.SqlSessionTemplate;

import vo.AdminVO;
import vo.MemberVO;
import vo.SellerVO;

public class AdminDAOImpl implements AdminDAO {
	
	private SqlSessionTemplate sqlSessionTemplate;
	private MemberVO memberVO;

	
	public AdminDAOImpl(SqlSessionTemplate sqlSessionTemplate) {
		this.sqlSessionTemplate = sqlSessionTemplate;
	}
	
	@Override
	public AdminVO selectAdminById(String adminId) {
		return sqlSessionTemplate.selectOne("adminDAO.selectAdminById", adminId);
	}
	
	@Override
	public int insertAdmin(AdminVO adminVO) {
		return sqlSessionTemplate.insert("adminDAO.insertAdmin", adminVO);
	}
	
	@Override
	public int selectAdminId(String adminId) {
		int result = sqlSessionTemplate.selectOne("adminDAO.selectAdminId", adminId);
		return result;
	}
	
	@Override
	public List<MemberVO> getMemberList(AdminVO adminVO) {
		return sqlSessionTemplate.selectList("adminDAO.getMemberList", adminVO);
	}
	
	@Override
	public List<SellerVO> getSellerList(AdminVO adminVO) {
		return sqlSessionTemplate.selectList("adminDAO.getSellerList", adminVO);
	}
	
	@Override
	public int deleteMemberById(MemberVO memberVo) {
		return sqlSessionTemplate.delete("adminDAO.deleteMemberById", memberVO);
	}



}
