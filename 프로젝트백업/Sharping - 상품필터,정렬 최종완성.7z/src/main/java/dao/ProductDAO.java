package dao;

import java.util.List;

import vo.ProductListVO;
import vo.SearchVO;

public interface ProductDAO {

	//상폼리스트
	public List<ProductListVO> getProductList(SearchVO search) throws Exception;

	
}
