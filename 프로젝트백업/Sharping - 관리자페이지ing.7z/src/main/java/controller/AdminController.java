package controller;

import javax.validation.Valid;

import org.mindrot.jbcrypt.BCrypt;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import exception.AlreadyExistingIdException;
import service.AdminService;
import vo.AdminVO;

@Controller
public class AdminController {
	
	private AdminService adminService;
	
	public AdminService getAdminService() {
		return adminService;
	}

	public void setAdminService(AdminService adminService) {
		this.adminService = adminService;
	}
	
	
	// 관리자 메인
	@RequestMapping("/admin")
	public String admin() {
		return "admin/AdminPage";
	}

	//새 관리자등록
	@RequestMapping("/registerAdmin")
	public String RegisterAdmin() {
		return "admin/RegisterAdmin";
	}
	
	// 아이디 중복확인
	@RequestMapping(value = "/adminIdCheck")
	@ResponseBody
	public int adminIdCheck(@Valid String adminId) {
		int result = adminService.adminIdCheck(adminId);
		return result;
	}
	
	//  새 관리자 등록 완료
	@RequestMapping(value = "/registerCompleteAdmin")
	public String registCompleteMember(@Valid AdminVO adminVO) {

		String pw = adminVO.getAdminPassword();
		String hashPw = BCrypt.hashpw(pw, BCrypt.gensalt());
		adminVO.setAdminPassword(hashPw);
		int result = adminService.adminIdCheck(adminVO.getAdminId());
		if (result == 1) {
			throw new AlreadyExistingIdException();
		}
		adminService.registAdmin(adminVO);
		return "admin/AdminPage";
	}
	
	// 카테고리관리
	@RequestMapping("/categoryManage")
	public String categoryManage() {
		return "admin/CategoryManage";
	}
	
	// 회원관리
	@RequestMapping("/memberManage")
	public String memberManage() {
		return "admin/MemberManage";
	}
	
	// 공지사항관리
	@RequestMapping("/noticeManage")
	public String noticeManage() {
		return "admin/NoticeManage";
	}
}
