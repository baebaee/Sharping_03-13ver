package dao;

import vo.OrderVO;

public interface OrderDAO {

	public abstract int insertOrder(OrderVO orderVO);
}
