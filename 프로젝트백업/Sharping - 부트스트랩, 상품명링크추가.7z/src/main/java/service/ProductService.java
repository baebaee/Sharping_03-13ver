package service;

import java.util.List;

import vo.ProductListVO;
import vo.SearchVO;


public interface ProductService {

	public List<ProductListVO> getProductList(SearchVO search) throws Exception;
	
}