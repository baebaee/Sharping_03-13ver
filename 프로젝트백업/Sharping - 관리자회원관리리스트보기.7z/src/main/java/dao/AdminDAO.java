package dao;

import java.util.List;

import vo.AdminVO;
import vo.MemberVO;
import vo.SellerVO;

public interface AdminDAO {

	public abstract AdminVO selectAdminById(String adminId);
	
	public abstract int insertAdmin(AdminVO adminVO);
	
	public abstract int selectAdminId(String adminId);
	
	//일반회원리스트
	public abstract List<MemberVO> getMemberList(AdminVO adminVO) throws Exception;
	
	//판매회원리스트
	public abstract List<SellerVO> getSellerList(AdminVO adminVO) throws Exception;

	
}
