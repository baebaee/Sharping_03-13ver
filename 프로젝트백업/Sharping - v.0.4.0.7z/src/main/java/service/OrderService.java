package service;

import vo.OrderVO;

public interface OrderService {

	public abstract int insertOrder(OrderVO orderVO);
}
