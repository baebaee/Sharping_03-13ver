package controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import service.ProductService;
import vo.SearchVO;

@Controller
public class ProductController {

	private ProductService productService;
	
	public void setProductService(ProductService productService) {
		this.productService = productService;
	}
	
	// 상품 검색 페이지
	@RequestMapping(value= "/searchProduct")
	public String SearchProduct() {
		return "MainPage";
	}
	
	// 상품 리스트 페이지
	@RequestMapping(value ="/productList", method = RequestMethod.GET)
	public String getProductList(Model model,
								@RequestParam(required=false, defaultValue = "productName") String searchType,
								@RequestParam(required=false) String keyword, @RequestParam(required=false) String keyword2,
								@RequestParam(required=false) String minPrice, @RequestParam(required=false) String maxPrice,
								@RequestParam(required=false) String checkDelivery,
								@RequestParam(required=false, defaultValue = "productDate") String sortType,
								@RequestParam(required=false) String highPrice, @RequestParam(required=false) String lowPrice,
								@RequestParam(required=false) String productDate
								) throws Exception{
		SearchVO search = new SearchVO();
		search.setSearchType(searchType);
		search.setSortType(sortType);
		search.setKeyword(keyword);
		search.setKeyword2(keyword2);
		search.setMinPrice(minPrice);
		search.setMaxPrice(maxPrice);
		search.setCheckDelivery(checkDelivery);
		search.setHighPrice(highPrice);
		search.setLowPrice(lowPrice);
		search.setProductDate(productDate);
		
		model.addAttribute("productList", productService.getProductList(search));
		model.addAttribute("keyword", keyword);
		model.addAttribute("keyword2",keyword2);
		model.addAttribute("minPrice", minPrice);
		model.addAttribute("maxPrice", maxPrice);
		return "product/SearchResult";
	}


}
